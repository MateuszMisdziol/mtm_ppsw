void InitTimer0(void);
void WaitOnTimer0(unsigned int uiTime);
void InitTimer0Match0(unsigned int uiDelayTime);
void WaitOnTimerMatch0(void);
